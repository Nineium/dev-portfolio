import { motion } from "framer-motion";

interface HeroProps {
  greeting: string;
  title: string;
  intro: string;
}

const Hero = ({ greeting, title, intro }: HeroProps) => {
  return (
    <section
      id="hero"
      className="min-h-screen flex flex-col items-center justify-center text-center px-4"
    >
      <motion.h1
        className="text-5xl md:text-6xl font-bold mb-4"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {greeting}
      </motion.h1>

      <motion.h2
        className="text-2xl md:text-3xl font-semibold text-gray-600 dark:text-gray-300 mb-6"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        {title}
      </motion.h2>

      <motion.p
        className="max-w-xl text-lg text-gray-700 dark:text-gray-400"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6, duration: 0.8 }}
      >
        {intro}
      </motion.p>
    </section>
  );
};

export default Hero;
